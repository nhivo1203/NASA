const launches = new Map();

const launch = {
	flightNumber: 100,
	misson: 'Test Launches Model',
	rocket: 'Test Rocket',
	launchDate: new Date('December 27, 2030'),
	destination: 'Kepler-442 b',
	customer: ['Nhi', 'Vo'],
	upcoming: true,
	success: true,
}

lauches.set(launch.flightNumber, launch);

module.exports = {
	lauches,
}